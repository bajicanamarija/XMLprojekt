
<!DOCTYPE html>
<html>
<head>
	<title>DreamFish</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;1,100;1,200;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>
	

	<div class="hero">
		<nav>
			<h2 class="logo">Dream<span>Fish</span></h2>
			<ul>
				<li><a href="#">Home</a></li>
				<li><a href="#">About Us</a></li>
				<li><a href="#">Services</a></li>
				<li><a href="#">Skills</a></li>
				<li><a href="#">Contact Us</a></li>
			</ul>
			<a href="#" class="btn">Book a tour</a>
		</nav>
		

		<div class="content">
			<h4>Hello, we are</h4>
			<h1>Dream <span>Fish</span></h1>
			<h3>Croatian fishing adventures.</h3>
			<div class="newslatter">
				<?php
				?>
				<form action="index.php" method="POST">
					<input type="email" name="email" id="mail" placeholder="Enter Your Email">
					<input type="submit" name="submit" value="Lets Start">
					<?php

				if (isset($_REQUEST['submit'])){
					$xml = new DOMDocument("1.0","UTF-8");
					$xml->load("xml.xml");

					$rootTag = $xml->getElementsbyTagName("document")->item(0);
					$dataTag = $xml->createElement("data");
					$emailTag = $xml->createElement("email",$_REQUEST['email']);

					$dataTag->appendChild($emailTag);
					$rootTag->appendchild($dataTag);
					
					$xml->save("xml.xml");

					
				}
				?>
				</form>
			</div>
		</div>
	</div>

	<!----About---->
	<section class="about">
		<div class="main">
			<img src="img/sunset.jpg">
			<div class="about-text">
				<h2>About Us</h2>
				<h5>Adventure <span>& Fun</span></h5>
				<p>Dream Fish team is available to provide fishermen a top-notch local fishing experience. A quality charter service will have everything you could need to enjoy catching fish and exploring the local area with your family and friends.</p>
				<button type="button">Let's Talk</button>
			</div>
		</div>
	</section>

	<!-----service----------->
	<div class="service">
		<div class="title">
			<h2>Our Services</h2>
		</div>

		<div class="box">
			<div class="card">
				<i class="fas fa-fish"></i>
				<h5>Big game fishing</h5>
				<div class="pra">
					<p>Big game fishing is fishing discipline full of adrenaline! Real Hemingway story about the battle between the man and the fish.</p>

					<p style="text-align: center;">
						<a class="button" href="#">Read More</a>
					</p>
				</div>
			</div>

			<div class="card">
				<i class="far fa-user"></i>
				<h5>Half-day fishing</h5>
				<div class="pra">
					<p>Book with 20% deposit, pay rest to captain,you will need to pay 20% deposit to guarantee your reservation.</p>

					<p style="text-align: center;">
						<a class="button" href="#">Read More</a>
					</p>
				</div>
			</div>

			<div class="card">
				<i class="far fa-bell"></i>
				<h5>Multi-day fishing</h5>
				<div class="pra">
					<p>Your safety is our priority! In case of bad weather conditions,trip can be postponed,shortened or cancelled.</p>

					<p style="text-align: center;">
						<a class="button" href="#">Read More</a>
					</p>
				</div>
			</div>
		</div>
	</div>

	<!------Contact Me------>
	<div class="contact-me">
		<p>Let us give you an experience of your life.</p>
		<a class="button-two" href="#">Make a reservation</a>
	</div>

	<!------footer--------->
	<footer>
		<p>Ana-Marija Bajić</p>
		<p>Student of Zagreb University of applied sciences</p>
		<div class="social">
			<a href="#"><i class="fab fa-facebook-f"></i></a>
			<a href="#"><i class="fab fa-instagram"></i></a>
			<a href="#"><i class="fab fa-twitter"></i></a>
		</div>
		<p class="end">CopyRight By Ana-Marija Bajić</p>
	</footer>
</body>
</html>